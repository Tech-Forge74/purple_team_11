# CampusConnect – Smart Campus Lost & Found

A complete, responsive web application designed for university campuses to report, track, match, and recover lost and found belongings.

## 🚀 Key Features & Modules

1. **Modern Purple & White Theme**:
   - Polished violet, indigo, and crisp slate-white design system.
   - Clean card typography, responsive layouts, subtle shadows, and status badges.
   - Mobile-first responsive navigation with drawer toggle.

2. **Lost Item Reporting Form**:
   - Title, category selector, campus location picker (16+ buildings & zones).
   - Date & optional time picker.
   - Detailed description and distinctive identifying marks.
   - Image upload with drag & drop, file picker, and real-time canvas-scaled preview.
   - Reporter contact details with privacy options.

3. **Found Item Reporting Form**:
   - Identical comprehensive reporting structure.
   - Custom ownership verification challenge/question field (e.g. "What sticker is on the back?").

4. **Browse Items Directory & Multi-Attribute Filters**:
   - Instant real-time search across titles, descriptions, categories, and campus locations.
   - Filter by type: *All Items*, *Lost Only*, *Found Only*.
   - Filter by category: Electronics, Wallets & Cards, IDs & Keys, Bags, Study Material, Clothing, Water Bottles, Other.
   - Filter by campus building/zone.
   - Filter by status: *Active*, *Claim Pending*, *Reunited*.
   - Filter by data source: Clearly distinguishes *User Reported* (`★ User Reported`) from *Demo Sample Data* (`Sample Data`).
   - Sorting: Newest first, oldest first, and alphabetical title.

5. **Smart Matching Engine**:
   - Multi-factor compatibility scoring comparing opposite report types (`lost` vs `found`).
   - Criteria factors:
     - **Category Match**: up to 35 points
     - **Title & Brand Keywords**: up to 30 points
     - **Description & Attribute Overlap**: up to 20 points
     - **Campus Location Proximity**: up to 15 points
     - **Date Proximity**: up to 5 points
   - Returns confidence levels (*High Confidence*, *Moderate Match*, *Possible Match*), match percentages, and transparent criteria breakdown.
   - Side-by-side comparison modal with direct claim CTA.

6. **Ownership Verification & Claim Flow**:
   - Allows users to claim found items.
   - Ownership verification form asks for proof of ownership (serials, lock screen wallpaper, internal contents, scratch details) and preferred campus handover desk.
   - Transitions item status to `Claim Pending`.

7. **Campus Recovery Dashboard**:
   - Summary pulse metrics: Total Reports, Active Lost, Active Found, High-Probability Matches, Reunited Items.
   - **All Submitted Reports Tab**: View status, inspect, toggle reunited, or delete.
   - **Incoming Claims Tab**: Review claimant details, student ID, proof of ownership, and "Approve & Reunite" or "Decline".
   - **Prototype Data Controls**: One-click "Reset to Sample Data" and "Clear All Data" controls.

8. **Persistent LocalStorage**:
   - All reports, claims, and status changes persist across browser refreshes.

---

## 📁 File Structure

```text
campus-connect/
├── index.html          # Main HTML5 application shell & modals
├── css/
│   └── styles.css      # Purple & white responsive styling system
├── js/
│   ├── data.js         # Realistic campus demo data, categories, locations & SVG generator
│   ├── storage.js      # LocalStorage persistence wrapper & CRUD methods
│   ├── matcher.js      # Multi-factor smart matching engine & similarity scorers
│   └── app.js          # SPA navigation, event listeners, filters, forms & modals
├── test_runner.js      # Automated unit & integration test suite
└── README.md           # Documentation
```

---

## 💻 How to Run Locally

You can run CampusConnect using any static web server:

### Option 1: Python HTTP Server (Recommended)
```bash
cd campus-connect
python -m http.server 8088
```
Then open your browser at:
`http://localhost:8088`

### Option 2: Node.js (http-server / npx serve)
```bash
npx serve campus-connect
```

### Option 3: Direct File Open
You can also open `index.html` directly in any modern web browser.

---

## 🧪 Running Automated Logic Tests

To run the automated test suite verifying storage initialization, sample data tagging, smart matching scoring, and claim status transitions:
```bash
node test_runner.js
```
