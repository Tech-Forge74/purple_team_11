/**
 * CampusConnect - Sample Data & Constants
 * Realistic initial campus items and locations.
 * Sample items are explicitly marked with `isSample: true`.
 */

const CAMPUS_LOCATIONS = [
  "Central Library - 1st Floor Study Common",
  "Central Library - 2nd Floor Quiet Stacks",
  "Central Library - 3rd Floor Digital Lab",
  "Student Union - Ground Floor Lounge",
  "Student Union - Food Court & Cafeteria",
  "Student Union - Bookstore",
  "Campus Sports Complex - Gym & Lockers",
  "Campus Sports Complex - Swimming Arena",
  "Engineering Building A - Lecture Hall 101",
  "Engineering Building B - Computer Lab 3",
  "Science & Research Hall - Bio Lab 204",
  "Humanities Building - Auditorium",
  "North Residential Dorms - Common Room",
  "South Residential Dorms - Quad Courtyard",
  "Campus Main Gate & Bus Terminal",
  "Administrative Building - Registrar Office"
];

const ITEM_CATEGORIES = [
  { id: "electronics", label: "Electronics & Gadgets", icon: "laptop" },
  { id: "wallets_cards", label: "Wallets & Payment Cards", icon: "credit-card" },
  { id: "ids_keys", label: "Student IDs & Keys", icon: "key" },
  { id: "bags_backpacks", label: "Bags & Backpacks", icon: "briefcase" },
  { id: "books_stationery", label: "Books & Study Material", icon: "book-open" },
  { id: "clothing_accessories", label: "Clothing & Accessories", icon: "tag" },
  { id: "personal_items", label: "Water Bottles & Tumblers", icon: "coffee" },
  { id: "other", label: "Other Belongings", icon: "box" }
];

// Helper SVG placeholder generator for realistic campus items
function generatePlaceholderSvg(category, text, color = "#6D28D9") {
  const iconPaths = {
    electronics: '<rect x="3" y="4" width="18" height="12" rx="2" stroke="white" stroke-width="2" fill="none"/><line x1="2" y1="20" x2="22" y2="20" stroke="white" stroke-width="2"/><circle cx="12" cy="16" r="1" fill="white"/>',
    wallets_cards: '<rect x="2" y="5" width="20" height="14" rx="2" stroke="white" stroke-width="2" fill="none"/><line x1="2" y1="10" x2="22" y2="10" stroke="white" stroke-width="2"/><rect x="6" y="14" width="4" height="2" fill="white"/>',
    ids_keys: '<circle cx="8" cy="15" r="4" stroke="white" stroke-width="2" fill="none"/><path d="M10.85 12.15L19 4M19 4H15M19 4V8" stroke="white" stroke-width="2" stroke-linecap="round"/>',
    bags_backpacks: '<path d="M6 8V6a4 4 0 0 1 8 0v2m-10 0h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" stroke="white" stroke-width="2" fill="none"/>',
    books_stationery: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15z" stroke="white" stroke-width="2" fill="none"/>',
    clothing_accessories: '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" stroke="white" stroke-width="2" fill="none"/><circle cx="7" cy="7" r="1.5" fill="white"/>',
    personal_items: '<path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z" stroke="white" stroke-width="2" fill="none"/>',
    other: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="white" stroke-width="2" fill="none"/>'
  };

  const path = iconPaths[category] || iconPaths.other;
  const sanitizedText = text.replace(/"/g, '&quot;');
  
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 240" width="100%" height="100%">
    <defs>
      <linearGradient id="grad-${category}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${color}" />
        <stop offset="100%" stop-color="#4C1D95" />
      </linearGradient>
      <pattern id="pattern" width="20" height="20" patternUnits="userSpaceOnUse">
        <circle cx="2" cy="2" r="1" fill="rgba(255,255,255,0.08)"/>
      </pattern>
    </defs>
    <rect width="400" height="240" fill="url(#grad-${category})" />
    <rect width="400" height="240" fill="url(#pattern)" />
    <circle cx="200" cy="95" r="42" fill="rgba(255,255,255,0.15)" />
    <g transform="translate(180, 75) scale(1.65)">
      ${path}
    </g>
    <text x="200" y="175" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="16" font-weight="600" fill="#FFFFFF" text-anchor="middle">${sanitizedText}</text>
    <text x="200" y="200" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" font-size="12" fill="rgba(255,255,255,0.75)" text-anchor="middle">CampusConnect Verified Item</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Initial realistic sample data
const INITIAL_SAMPLE_ITEMS = [
  // Pair 1: AirPods Pro (Lost & Found match pair)
  {
    id: "item_sample_1",
    type: "lost",
    title: "Apple AirPods Pro 2nd Gen",
    category: "electronics",
    description: "Lost my white AirPods Pro with a navy blue silicone protective case and small silver carabiner clip. Left them on a desk after finishing study group.",
    location: "Student Union - Ground Floor Lounge",
    date: "2026-11-14",
    time: "15:30",
    reporterName: "Maya Lin",
    reporterContact: "maya.lin@campus.edu",
    contactVisibility: "protected",
    status: "active",
    imageUrl: generatePlaceholderSvg("electronics", "Apple AirPods Pro 2", "#7C3AED"),
    secretVerificationHint: "Engraving on back of charging case or color of carabiner ring",
    isSample: true,
    createdAt: "2026-11-14T16:00:00Z"
  },
  {
    id: "item_sample_2",
    type: "found",
    title: "AirPods in Dark Blue Silicone Case",
    category: "electronics",
    description: "Found wireless earbud case with dark blue silicone cover and silver metal ring under one of the corner sofas near the snack vending machines.",
    location: "Student Union - Ground Floor Lounge",
    date: "2026-11-14",
    time: "17:15",
    reporterName: "Officer Dave Martinez",
    reporterContact: "campus.security@campus.edu",
    contactVisibility: "public",
    status: "active",
    imageUrl: generatePlaceholderSvg("electronics", "Navy Blue AirPods Case", "#6D28D9"),
    secretVerificationHint: "Must confirm interior model markings or device Bluetooth nickname",
    isSample: true,
    createdAt: "2026-11-14T17:45:00Z"
  },

  // Pair 2: Student ID & Keys (Lost & Found match pair)
  {
    id: "item_sample_3",
    type: "lost",
    title: "Brass Dorm Key with Purple Lanyard",
    category: "ids_keys",
    description: "Lost my room key attached to a purple university lanyard with 'Class of 2027' lettering and a small brass bottle opener.",
    location: "Engineering Building A - Lecture Hall 101",
    date: "2026-11-15",
    time: "11:00",
    reporterName: "Liam Johnson",
    reporterContact: "liam.j@campus.edu",
    contactVisibility: "protected",
    status: "active",
    imageUrl: generatePlaceholderSvg("ids_keys", "Dorm Key & Lanyard", "#8B5CF6"),
    secretVerificationHint: "Dorm room number stamped on key edge",
    isSample: true,
    createdAt: "2026-11-15T11:45:00Z"
  },
  {
    id: "item_sample_4",
    type: "found",
    title: "Brass Key on Purple University Lanyard",
    category: "ids_keys",
    description: "Turned into lecturer desk after morning Physics 201 lecture. Single key on purple strap with metal opener attachment.",
    location: "Engineering Building A - Lecture Hall 101",
    date: "2026-11-15",
    time: "12:10",
    reporterName: "Prof. Clara Vance",
    reporterContact: "cvance@campus.edu",
    contactVisibility: "public",
    status: "active",
    imageUrl: generatePlaceholderSvg("ids_keys", "Found Key with Lanyard", "#7C3AED"),
    secretVerificationHint: "Dorm number digits stamped on the brass head",
    isSample: true,
    createdAt: "2026-11-15T12:30:00Z"
  },

  // Pair 3: Brown Leather Wallet (Lost & Found match pair)
  {
    id: "item_sample_5",
    type: "lost",
    title: "Brown Leather Timberland Bifold Wallet",
    category: "wallets_cards",
    description: "Brown bi-fold leather wallet containing student card (Marcus Zhao), debit card, and subway transit pass. Might have fallen out while working out.",
    location: "Campus Sports Complex - Gym & Lockers",
    date: "2026-11-13",
    time: "18:45",
    reporterName: "Marcus Zhao",
    reporterContact: "marcus.zhao@campus.edu",
    contactVisibility: "protected",
    status: "active",
    imageUrl: generatePlaceholderSvg("wallets_cards", "Brown Bifold Wallet", "#A855F7"),
    secretVerificationHint: "Name on cards inside or transit pass balance",
    isSample: true,
    createdAt: "2026-11-13T19:30:00Z"
  },
  {
    id: "item_sample_6",
    type: "found",
    title: "Men's Brown Leather Wallet with Student ID",
    category: "wallets_cards",
    description: "Handed to gym front reception. Brown distressed leather wallet containing campus ID card and several cards. Kept securely in the staff safe.",
    location: "Campus Sports Complex - Gym & Lockers",
    date: "2026-11-13",
    time: "20:00",
    reporterName: "Gym Front Desk (Staff Elena)",
    reporterContact: "sportsdesk@campus.edu",
    contactVisibility: "public",
    status: "claim_pending",
    imageUrl: generatePlaceholderSvg("wallets_cards", "Leather Wallet in Safe", "#6D28D9"),
    secretVerificationHint: "Provide photo ID matching student card or bank card last 4 digits",
    isSample: true,
    createdAt: "2026-11-13T20:20:00Z"
  },

  // Pair 4: Hydro Flask Water Bottle (Lost & Found match pair)
  {
    id: "item_sample_7",
    type: "lost",
    title: "Hydro Flask 32oz Yellow Water Bottle",
    category: "personal_items",
    description: "Bright lemon yellow Hydro Flask with black flex cap lid. Has a national park sticker and a small dent near the bottom rim.",
    location: "Central Library - 2nd Floor Quiet Stacks",
    date: "2026-11-15",
    time: "14:00",
    reporterName: "Samantha Brooks",
    reporterContact: "sam.brooks@campus.edu",
    contactVisibility: "public",
    status: "active",
    imageUrl: generatePlaceholderSvg("personal_items", "Yellow 32oz Hydro Flask", "#D97706"),
    secretVerificationHint: "Which specific national park sticker is on it",
    isSample: true,
    createdAt: "2026-11-15T15:10:00Z"
  },
  {
    id: "item_sample_8",
    type: "found",
    title: "Yellow Insulated Flask with Stickers",
    category: "personal_items",
    description: "Stainless steel insulated water bottle left on round study table in stacks. Yellow color with black handle lid and outdoor sticker.",
    location: "Central Library - 2nd Floor Quiet Stacks",
    date: "2026-11-15",
    time: "16:45",
    reporterName: "Library Circulation Desk",
    reporterContact: "library-circ@campus.edu",
    contactVisibility: "public",
    status: "active",
    imageUrl: generatePlaceholderSvg("personal_items", "Yellow Insulated Flask", "#B45309"),
    secretVerificationHint: "Identify sticker name or exact capacity",
    isSample: true,
    createdAt: "2026-11-15T17:00:00Z"
  },

  // Item 9: Backpack (Lost only - waiting for match)
  {
    id: "item_sample_9",
    type: "lost",
    title: "Black Herschel Little America Backpack",
    category: "bags_backpacks",
    description: "Classic black canvas backpack with brown synthetic leather straps. Contains notebook, graphing calculator, and blue umbrella in side sleeve.",
    location: "Student Union - Food Court & Cafeteria",
    date: "2026-11-16",
    time: "12:30",
    reporterName: "Kevin Patel",
    reporterContact: "k.patel@campus.edu",
    contactVisibility: "protected",
    status: "active",
    imageUrl: generatePlaceholderSvg("bags_backpacks", "Black Herschel Backpack", "#4C1D95"),
    secretVerificationHint: "Subject written on spiral notebook cover inside",
    isSample: true,
    createdAt: "2026-11-16T13:15:00Z"
  },

  // Item 10: Ray-Ban Sunglasses (Found only - waiting for claim)
  {
    id: "item_sample_10",
    type: "found",
    title: "Ray-Ban Aviator Sunglasses in Black Case",
    category: "clothing_accessories",
    description: "Found on the bleachers near the track. Gold frames with polarized dark green lenses in a black textured Ray-Ban snap case.",
    location: "Campus Sports Complex - Swimming Arena",
    date: "2026-11-16",
    time: "09:30",
    reporterName: "Coach Jackson",
    reporterContact: "athletics@campus.edu",
    contactVisibility: "public",
    status: "active",
    imageUrl: generatePlaceholderSvg("clothing_accessories", "Ray-Ban Sunglasses", "#5B21B6"),
    secretVerificationHint: "Cleaning cloth color inside case or frame size code",
    isSample: true,
    createdAt: "2026-11-16T10:00:00Z"
  },

  // Item 11: Resolved item for demonstration of completed cycle
  {
    id: "item_sample_11",
    type: "lost",
    title: "Silver Dell Inspiron 15 Laptop",
    category: "electronics",
    description: "Reunited with owner! Silver 15-inch laptop reported lost in Computer Lab 3.",
    location: "Engineering Building B - Computer Lab 3",
    date: "2026-11-10",
    time: "16:00",
    reporterName: "Rachel Chen",
    reporterContact: "rachel.c@campus.edu",
    contactVisibility: "protected",
    status: "resolved",
    imageUrl: generatePlaceholderSvg("electronics", "Dell Laptop [Reunited]", "#059669"),
    secretVerificationHint: "Verified by login credentials",
    isSample: true,
    createdAt: "2026-11-10T16:30:00Z"
  }
];

const INITIAL_SAMPLE_CLAIMS = [
  {
    id: "claim_sample_1",
    itemId: "item_sample_6",
    claimerName: "Marcus Zhao",
    claimerEmail: "marcus.zhao@campus.edu",
    claimerPhone: "+1 (555) 349-1102",
    studentId: "STU-994821",
    verificationProof: "The student ID inside has my name Marcus Zhao, ID number ending in 821, and the gym card is for the Campus Fitness Center with barcode sticker.",
    preferredPickupLocation: "Campus Sports Complex - Gym Front Desk",
    status: "pending",
    date: "2026-11-14T09:15:00Z",
    notes: "Awaiting claimant to present matching photo government ID at front desk."
  }
];
