/**
 * CampusConnect - Smart Matching Engine
 * Compares Lost and Found reports using item name, category, description, location, and date proximity.
 */

const STOP_WORDS = new Set([
  "the", "a", "an", "and", "or", "in", "on", "at", "to", "for", "of", "with", "by", "from",
  "my", "i", "it", "is", "was", "this", "that", "these", "those", "have", "has", "had",
  "left", "lost", "found", "near", "around", "inside", "outside", "room", "floor", "area", "desk"
]);

const COLOR_KEYWORDS = [
  "black", "white", "silver", "gold", "blue", "navy", "red", "yellow", "green", 
  "purple", "brown", "grey", "gray", "pink", "orange", "tan", "brass", "rose"
];

const BRAND_KEYWORDS = [
  "apple", "airpods", "macbook", "iphone", "ipad", "dell", "hp", "lenovo", "asus",
  "samsung", "sony", "bose", "hydro flask", "stanley", "yeti", "ray-ban", "oakley",
  "fossil", "timberland", "herschel", "north face", "nike", "adidas", "casio", "ti-84"
];

const Matcher = {
  /**
   * Tokenizes and normalizes text into cleaned meaningful word tokens
   */
  tokenize(text) {
    if (!text) return [];
    return text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter(w => w.length > 2 && !STOP_WORDS.has(w));
  },

  /**
   * Extracts recognized colors from text
   */
  extractColors(text) {
    if (!text) return [];
    const lower = text.toLowerCase();
    return COLOR_KEYWORDS.filter(color => lower.includes(color));
  },

  /**
   * Compares two specific items (one must be lost, one found)
   * @param {Object} itemA 
   * @param {Object} itemB 
   * @returns {Object|null} Match result with score, confidence, and reasons
   */
  compare(itemA, itemB) {
    // Only match opposite types (lost vs found)
    if (!itemA || !itemB || itemA.id === itemB.id || itemA.type === itemB.type) {
      return null;
    }

    let score = 0;
    const reasons = [];

    // 1. Category comparison (Max: 35 points)
    if (itemA.category === itemB.category) {
      score += 35;
      const catObj = ITEM_CATEGORIES.find(c => c.id === itemA.category);
      reasons.push({
        factor: "Category",
        points: 35,
        text: `Exact category match: "${catObj ? catObj.label : itemA.category}"`
      });
    }

    // 2. Title & Keywords comparison (Max: 30 points)
    const tokensA = this.tokenize(itemA.title);
    const tokensB = this.tokenize(itemB.title);
    const commonTitleTokens = tokensA.filter(t => tokensB.includes(t));

    // Check brand/model overlaps
    const titleA_lower = (itemA.title || "").toLowerCase();
    const titleB_lower = (itemB.title || "").toLowerCase();
    const matchedBrands = BRAND_KEYWORDS.filter(b => titleA_lower.includes(b) && titleB_lower.includes(b));

    let titlePoints = 0;
    if (commonTitleTokens.length > 0 || matchedBrands.length > 0) {
      titlePoints = Math.min(30, (commonTitleTokens.length * 10) + (matchedBrands.length * 15));
      score += titlePoints;
      
      const matchedHighlights = Array.from(new Set([...commonTitleTokens, ...matchedBrands]));
      reasons.push({
        factor: "Item Name",
        points: titlePoints,
        text: `Title keyword match: "${matchedHighlights.slice(0, 4).join(', ')}"`
      });
    }

    // 3. Description & Attribute Details (Max: 20 points)
    const descTokensA = this.tokenize(itemA.description);
    const descTokensB = this.tokenize(itemB.description);
    const descOverlap = descTokensA.filter(t => descTokensB.includes(t) && !commonTitleTokens.includes(t));

    // Color match
    const colorsA = this.extractColors(itemA.title + " " + itemA.description);
    const colorsB = this.extractColors(itemB.title + " " + itemB.description);
    const matchingColors = colorsA.filter(c => colorsB.includes(c));

    let descPoints = 0;
    if (descOverlap.length > 0 || matchingColors.length > 0) {
      descPoints = Math.min(20, (descOverlap.length * 4) + (matchingColors.length * 8));
      score += descPoints;
      
      const descHighlights = [];
      if (matchingColors.length > 0) descHighlights.push(`Color: ${matchingColors.join(', ')}`);
      if (descOverlap.length > 0) descHighlights.push(`Details: ${descOverlap.slice(0, 3).join(', ')}`);
      
      reasons.push({
        factor: "Description & Attributes",
        points: descPoints,
        text: `Matching details (${descHighlights.join('; ')})`
      });
    }

    // 4. Campus Location Match (Max: 15 points)
    if (itemA.location && itemB.location) {
      const locA = itemA.location.toLowerCase();
      const locB = itemB.location.toLowerCase();

      if (locA === locB) {
        score += 15;
        reasons.push({
          factor: "Campus Location",
          points: 15,
          text: `Exact location match: "${itemA.location}"`
        });
      } else {
        // Check building/zone level matching (e.g. "Library", "Student Union", "Sports Complex", "Engineering")
        const campusZones = ["library", "student union", "sports", "engineering", "science", "humanities", "dorm", "gate", "cafeteria"];
        const matchedZone = campusZones.find(z => locA.includes(z) && locB.includes(z));
        if (matchedZone) {
          score += 10;
          reasons.push({
            factor: "Campus Zone",
            points: 10,
            text: `Proximity match: Both in/around campus ${matchedZone.toUpperCase()} area`
          });
        }
      }
    }

    // 5. Date Proximity (Max: 5 points bonus)
    if (itemA.date && itemB.date) {
      const dateA = new Date(itemA.date);
      const dateB = new Date(itemB.date);
      const diffDays = Math.abs((dateA - dateB) / (1000 * 60 * 60 * 24));

      if (diffDays <= 1) {
        score += 5;
        reasons.push({
          factor: "Date Proximity",
          points: 5,
          text: `Reported within 24 hours of each other`
        });
      } else if (diffDays <= 4) {
        score += 3;
        reasons.push({
          factor: "Date Proximity",
          points: 3,
          text: `Reported within ${Math.round(diffDays)} days of each other`
        });
      }
    }

    // Cap total score at 100%
    const finalScore = Math.min(100, score);

    // Determine confidence label
    let confidence = "Low";
    let badgeClass = "badge-low";
    if (finalScore >= 75) {
      confidence = "High Confidence";
      badgeClass = "badge-high";
    } else if (finalScore >= 50) {
      confidence = "Moderate Match";
      badgeClass = "badge-medium";
    } else if (finalScore >= 35) {
      confidence = "Possible Match";
      badgeClass = "badge-possible";
    }

    return {
      score: finalScore,
      confidence,
      badgeClass,
      reasons,
      itemA,
      itemB,
      lostItem: itemA.type === "lost" ? itemA : itemB,
      foundItem: itemA.type === "found" ? itemA : itemB
    };
  },

  /**
   * Find all matching counterparts for a single item
   * @param {Object} targetItem 
   * @param {Array} allItems 
   * @param {number} minScore Minimum threshold (default 35%)
   */
  findMatchesFor(targetItem, allItems, minScore = 35) {
    if (!targetItem || !Array.isArray(allItems)) return [];
    
    const results = [];
    allItems.forEach(candidate => {
      if (candidate.id !== targetItem.id && candidate.type !== targetItem.type) {
        const match = this.compare(targetItem, candidate);
        if (match && match.score >= minScore) {
          results.push(match);
        }
      }
    });

    return results.sort((a, b) => b.score - a.score);
  },

  /**
   * Scans entire campus catalog for high-probability pairs
   */
  getAllCampusMatches(allItems, minScore = 40) {
    if (!Array.isArray(allItems)) return [];

    const lostItems = allItems.filter(i => i.type === "lost" && i.status !== "resolved");
    const foundItems = allItems.filter(i => i.type === "found" && i.status !== "resolved");

    const pairs = [];
    const seenPairKeys = new Set();

    lostItems.forEach(lost => {
      foundItems.forEach(found => {
        const pairKey = `${lost.id}_${found.id}`;
        if (!seenPairKeys.has(pairKey)) {
          seenPairKeys.add(pairKey);
          const match = this.compare(lost, found);
          if (match && match.score >= minScore) {
            pairs.push(match);
          }
        }
      });
    });

    return pairs.sort((a, b) => b.score - a.score);
  }
};
