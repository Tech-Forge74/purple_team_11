/**
 * CampusConnect - Application Controller
 * Handles SPA navigation, form handling, browsing & filters,
 * smart matching UI, dashboard metrics, claims verification, and modals.
 */

const App = {
  currentView: "home",
  activeFilters: {
    search: "",
    type: "all",
    category: "all",
    location: "all",
    status: "all",
    source: "all",
    sort: "newest"
  },
  imageData: {
    lost: null,
    found: null
  },

  /**
   * Initializes application on DOM load
   */
  init() {
    this.populateDropdowns();
    this.setupDatePickers();
    this.setupImageUploads();
    this.setupMobileMenu();
    this.setupHashRouting();
    this.refreshAllData();

    // Listen for hash changes
    window.addEventListener("hashchange", () => {
      this.handleHashRoute();
    });

    // Close modals on Escape key
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        this.closeAllModals();
      }
    });

    console.log("CampusConnect initialized successfully.");
  },

  /**
   * Populate Category and Campus Location selects across forms and filters
   */
  populateDropdowns() {
    // Categories
    const categoryOptionsHtml = ITEM_CATEGORIES.map(
      cat => `<option value="${cat.id}">${cat.label}</option>`
    ).join("");

    const lostCat = document.getElementById("lost-category");
    const foundCat = document.getElementById("found-category");
    const browseCat = document.getElementById("browse-filter-category");

    if (lostCat) lostCat.innerHTML += categoryOptionsHtml;
    if (foundCat) foundCat.innerHTML += categoryOptionsHtml;
    if (browseCat) browseCat.innerHTML += categoryOptionsHtml;

    // Campus Locations
    const locationOptionsHtml = CAMPUS_LOCATIONS.map(
      loc => `<option value="${loc}">${loc}</option>`
    ).join("");

    const lostLoc = document.getElementById("lost-location");
    const foundLoc = document.getElementById("found-location");
    const browseLoc = document.getElementById("browse-filter-location");

    if (lostLoc) lostLoc.innerHTML += locationOptionsHtml;
    if (foundLoc) foundLoc.innerHTML += locationOptionsHtml;
    if (browseLoc) browseLoc.innerHTML += locationOptionsHtml;
  },

  /**
   * Set default date for report forms to today
   */
  setupDatePickers() {
    const today = new Date().toISOString().split("T")[0];
    const lostDate = document.getElementById("lost-date");
    const foundDate = document.getElementById("found-date");
    if (lostDate) lostDate.value = today;
    if (foundDate) foundDate.value = today;
  },

  /**
   * Setup drag & drop and file input readers for image uploads
   */
  setupImageUploads() {
    ["lost", "found"].forEach(type => {
      const dropzone = document.getElementById(`${type}-dropzone`);
      const fileInput = document.getElementById(`${type}-image-input`);

      if (!dropzone || !fileInput) return;

      // Click is handled by onclick in HTML
      // Drag & drop handlers
      ["dragenter", "dragover"].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropzone.classList.add("dragover");
        });
      });

      ["dragleave", "drop"].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropzone.classList.remove("dragover");
        });
      });

      dropzone.addEventListener("drop", (e) => {
        const files = e.dataTransfer.files;
        if (files && files[0]) {
          this.handleImageFile(files[0], type);
        }
      });

      fileInput.addEventListener("change", (e) => {
        if (e.target.files && e.target.files[0]) {
          this.handleImageFile(e.target.files[0], type);
        }
      });
    });
  },

  /**
   * Read file to Base64 data URL with client-side compression
   */
  handleImageFile(file, type) {
    if (!file.type.startsWith("image/")) {
      this.showToast("Please upload a valid image file (PNG, JPG, WebP)", "error");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      this.showToast("File is too large. Please select an image under 5MB.", "error");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Simple canvas downscale for fast localStorage storage
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);

        this.imageData[type] = dataUrl;

        // Update preview UI
        const previewContainer = document.getElementById(`${type}-preview-container`);
        const previewImg = document.getElementById(`${type}-preview-img`);
        const dropzone = document.getElementById(`${type}-dropzone`);

        if (previewContainer && previewImg && dropzone) {
          previewImg.src = dataUrl;
          previewContainer.style.display = "block";
          dropzone.style.display = "none";
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  },

  /**
   * Clear uploaded image preview
   */
  clearImagePreview(type) {
    this.imageData[type] = null;
    const previewContainer = document.getElementById(`${type}-preview-container`);
    const previewImg = document.getElementById(`${type}-preview-img`);
    const dropzone = document.getElementById(`${type}-dropzone`);
    const fileInput = document.getElementById(`${type}-image-input`);

    if (previewContainer) previewContainer.style.display = "none";
    if (previewImg) previewImg.src = "";
    if (dropzone) dropzone.style.display = "block";
    if (fileInput) fileInput.value = "";
  },

  /**
   * Setup Mobile menu drawer toggle
   */
  setupMobileMenu() {
    const toggleBtn = document.getElementById("mobile-toggle");
    const navLinks = document.getElementById("nav-links");

    if (toggleBtn && navLinks) {
      toggleBtn.addEventListener("click", () => {
        navLinks.classList.toggle("mobile-open");
      });
    }
  },

  /**
   * Navigation router
   */
  navigateTo(viewId) {
    // Hide all view sections
    document.querySelectorAll(".view-section").forEach(sec => {
      sec.classList.remove("active-view");
    });

    // Show target section
    const target = document.getElementById(`view-${viewId}`);
    if (target) {
      target.classList.add("active-view");
      this.currentView = viewId;
      window.location.hash = viewId;
    }

    // Update active nav links
    document.querySelectorAll(".nav-link").forEach(link => {
      if (link.getAttribute("data-view") === viewId) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });

    // Close mobile menu if open
    const navLinks = document.getElementById("nav-links");
    if (navLinks) navLinks.classList.remove("mobile-open");

    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });

    // Refresh view specific components
    if (viewId === "home") {
      this.renderHomeRecent();
      this.updatePulseMetrics();
    } else if (viewId === "browse") {
      this.renderBrowseItems();
    } else if (viewId === "matches") {
      this.renderMatchesView();
    } else if (viewId === "dashboard") {
      this.renderDashboard();
    }
  },

  /**
   * Handle hash changes (e.g., #browse, #dashboard, #matches)
   */
  setupHashRouting() {
    this.handleHashRoute();
  },

  handleHashRoute() {
    const hash = window.location.hash.replace("#", "").trim();
    const validViews = ["home", "browse", "matches", "dashboard", "report-lost", "report-found"];
    if (validViews.includes(hash)) {
      this.navigateTo(hash);
    } else {
      this.navigateTo("home");
    }
  },

  /**
   * Refresh all counts, badges, and cached views
   */
  refreshAllData() {
    this.updatePulseMetrics();
    this.renderHomeRecent();
    this.renderBrowseItems();
    this.renderMatchesView();
    this.renderDashboard();
  },

  /**
   * Updates quick statistics on landing page and nav badge
   */
  updatePulseMetrics() {
    const items = StorageService.getItems();
    const total = items.length;
    const lost = items.filter(i => i.type === "lost" && i.status !== "resolved").length;
    const found = items.filter(i => i.type === "found" && i.status !== "resolved").length;
    const reunited = items.filter(i => i.status === "resolved").length;

    // Matches count
    const matches = Matcher.getAllCampusMatches(items);

    // Update home stats
    const elTotal = document.getElementById("home-stat-total");
    const elLost = document.getElementById("home-stat-lost");
    const elFound = document.getElementById("home-stat-found");
    const elReunited = document.getElementById("home-stat-reunited");
    const navMatchBadge = document.getElementById("nav-matches-badge");

    if (elTotal) elTotal.textContent = total;
    if (elLost) elLost.textContent = lost;
    if (elFound) elFound.textContent = found;
    if (elReunited) elReunited.textContent = reunited;
    if (navMatchBadge) navMatchBadge.textContent = matches.length;

    // Update dashboard metrics
    const dashTotal = document.getElementById("dash-stat-total");
    const dashLost = document.getElementById("dash-stat-lost");
    const dashFound = document.getElementById("dash-stat-found");
    const dashMatches = document.getElementById("dash-stat-matches");
    const dashReunited = document.getElementById("dash-stat-reunited");

    if (dashTotal) dashTotal.textContent = total;
    if (dashLost) dashLost.textContent = lost;
    if (dashFound) dashFound.textContent = found;
    if (dashMatches) dashMatches.textContent = matches.length;
    if (dashReunited) dashReunited.textContent = reunited;
  },

  /**
   * Renders the 3 most recent items on the Home page
   */
  renderHomeRecent() {
    const container = document.getElementById("home-recent-grid");
    if (!container) return;

    const items = StorageService.getItems();
    const recent = items.slice(0, 3);

    if (recent.length === 0) {
      container.innerHTML = `<div class="empty-state"><h3>No reports available yet</h3></div>`;
      return;
    }

    container.innerHTML = recent.map(item => this.createItemCardHtml(item)).join("");
  },

  /**
   * Form submit handler for Lost or Found report
   */
  handleFormSubmit(event, type) {
    event.preventDefault();

    const title = document.getElementById(`${type}-title`).value.trim();
    const category = document.getElementById(`${type}-category`).value;
    const location = document.getElementById(`${type}-location`).value;
    const date = document.getElementById(`${type}-date`).value;
    const time = document.getElementById(`${type}-time`).value;
    const description = document.getElementById(`${type}-description`).value.trim();
    const secretVerification = document.getElementById(`${type}-secret`).value.trim();
    const reporterName = document.getElementById(`${type}-reporter-name`).value.trim();
    const reporterContact = document.getElementById(`${type}-reporter-email`).value.trim();

    // Image URL: use uploaded image or generate category SVG
    let imageUrl = this.imageData[type];
    if (!imageUrl) {
      const color = type === "lost" ? "#DC2626" : "#6D28D9";
      imageUrl = generatePlaceholderSvg(category, title, color);
    }

    const newItemData = {
      type,
      title,
      category,
      location,
      date,
      time,
      description,
      secretVerificationHint: secretVerification,
      reporterName,
      reporterContact,
      contactVisibility: "public",
      status: "active",
      imageUrl
    };

    // Save to storage (User submitted reports will be tagged isSample: false)
    const savedItem = StorageService.addItem(newItemData);

    // Reset form and image preview
    event.target.reset();
    this.clearImagePreview(type);
    this.setupDatePickers();

    this.showToast(
      `✓ Successfully published ${type === "lost" ? "Lost Item" : "Found Item"} report!`,
      "success"
    );

    this.refreshAllData();

    // Check if there are immediate matches for this new report!
    const allItems = StorageService.getItems();
    const immediateMatches = Matcher.findMatchesFor(savedItem, allItems);

    if (immediateMatches.length > 0) {
      this.showToast(
        `Smart Match Alert: Found ${immediateMatches.length} potential counterpart match(es) for your item!`,
        "info"
      );
      this.navigateTo("matches");
    } else {
      this.navigateTo("browse");
    }
  },

  /**
   * Type filter buttons (All / Lost / Found)
   */
  setTypeFilter(type) {
    this.activeFilters.type = type;
    document.querySelectorAll(".type-filter-btn").forEach(btn => {
      if (btn.getAttribute("data-type") === type) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });
    this.renderBrowseItems();
  },

  /**
   * Filter inputs change handler
   */
  handleFilterChange() {
    this.activeFilters.search = document.getElementById("browse-search").value.trim().toLowerCase();
    this.activeFilters.category = document.getElementById("browse-filter-category").value;
    this.activeFilters.location = document.getElementById("browse-filter-location").value;
    this.activeFilters.status = document.getElementById("browse-filter-status").value;
    this.activeFilters.source = document.getElementById("browse-filter-source").value;
    this.activeFilters.sort = document.getElementById("browse-filter-sort").value;

    this.renderBrowseItems();
  },

  /**
   * Reset all filters to default
   */
  resetBrowseFilters() {
    this.activeFilters = {
      search: "",
      type: "all",
      category: "all",
      location: "all",
      status: "all",
      source: "all",
      sort: "newest"
    };

    document.getElementById("browse-search").value = "";
    document.getElementById("browse-filter-category").value = "all";
    document.getElementById("browse-filter-location").value = "all";
    document.getElementById("browse-filter-status").value = "all";
    document.getElementById("browse-filter-source").value = "all";
    document.getElementById("browse-filter-sort").value = "newest";

    this.setTypeFilter("all");
  },

  /**
   * Render items grid based on active search & filters
   */
  renderBrowseItems() {
    const grid = document.getElementById("browse-items-grid");
    const countLabel = document.getElementById("browse-count-label");
    if (!grid) return;

    let items = StorageService.getItems();

    // 1. Type filter
    if (this.activeFilters.type !== "all") {
      items = items.filter(i => i.type === this.activeFilters.type);
    }

    // 2. Category filter
    if (this.activeFilters.category !== "all") {
      items = items.filter(i => i.category === this.activeFilters.category);
    }

    // 3. Location filter
    if (this.activeFilters.location !== "all") {
      items = items.filter(i => i.location === this.activeFilters.location);
    }

    // 4. Status filter
    if (this.activeFilters.status !== "all") {
      items = items.filter(i => i.status === this.activeFilters.status);
    }

    // 5. Source filter (Sample Data vs User Reported)
    if (this.activeFilters.source === "user") {
      items = items.filter(i => i.isSample !== true);
    } else if (this.activeFilters.source === "sample") {
      items = items.filter(i => i.isSample === true);
    }

    // 6. Search query
    if (this.activeFilters.search) {
      const q = this.activeFilters.search;
      items = items.filter(i => {
        return (
          (i.title && i.title.toLowerCase().includes(q)) ||
          (i.description && i.description.toLowerCase().includes(q)) ||
          (i.location && i.location.toLowerCase().includes(q)) ||
          (i.category && i.category.toLowerCase().includes(q))
        );
      });
    }

    // 7. Sorting
    if (this.activeFilters.sort === "newest") {
      items.sort((a, b) => new Date(b.date) - new Date(a.date));
    } else if (this.activeFilters.sort === "oldest") {
      items.sort((a, b) => new Date(a.date) - new Date(b.date));
    } else if (this.activeFilters.sort === "title_asc") {
      items.sort((a, b) => a.title.localeCompare(b.title));
    }

    // Update count label
    if (countLabel) {
      countLabel.textContent = `Showing ${items.length} item${items.length === 1 ? "" : "s"}`;
    }

    // Empty state
    if (items.length === 0) {
      grid.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <h3>No matching campus items found</h3>
          <p>Try adjusting your search keywords, clearing selected filters, or report a new item.</p>
          <button class="btn btn-primary" onclick="App.resetBrowseFilters()">Reset Filters</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = items.map(item => this.createItemCardHtml(item)).join("");
  },

  /**
   * Generates HTML for an item card
   */
  createItemCardHtml(item) {
    const isLost = item.type === "lost";
    const typeBadgeClass = isLost ? "badge-lost" : "badge-found";
    const typeLabel = isLost ? "Lost" : "Found";

    let statusBadgeClass = "badge-active";
    let statusLabel = "Active";
    if (item.status === "claim_pending") {
      statusBadgeClass = "badge-pending";
      statusLabel = "Claim Pending";
    } else if (item.status === "resolved") {
      statusBadgeClass = "badge-resolved";
      statusLabel = "Reunited";
    }

    // Clearly distinguish Sample Data vs User Submission
    const sourceBadge = item.isSample
      ? `<span class="badge badge-sample" title="Demonstration sample data">Sample Data</span>`
      : `<span class="badge badge-user" title="Submitted by a real campus user">★ User Reported</span>`;

    const catObj = ITEM_CATEGORIES.find(c => c.id === item.category);
    const categoryName = catObj ? catObj.label : item.category;

    // Action button: for found items that are not resolved, show "Claim"
    let claimButtonHtml = "";
    if (item.type === "found" && item.status !== "resolved") {
      claimButtonHtml = `
        <button class="btn btn-sm btn-primary" onclick="App.openClaimModal('${item.id}')">
          Claim Item
        </button>
      `;
    }

    return `
      <div class="item-card" data-item-id="${item.id}">
        <div class="item-thumb-wrapper">
          <img src="${item.imageUrl}" alt="${item.title}" loading="lazy">
          <div class="item-badges-overlay">
            <span class="badge ${typeBadgeClass}">${typeLabel}</span>
            <span class="badge ${statusBadgeClass}">${statusLabel}</span>
          </div>
        </div>

        <div class="item-card-body">
          <div class="item-origin-tag">
            ${sourceBadge}
          </div>

          <h3 class="item-card-title">${this.escapeHtml(item.title)}</h3>
          <p class="item-card-desc">${this.escapeHtml(item.description)}</p>

          <div class="item-meta-list">
            <div class="item-meta-row">
              <svg class="item-meta-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><circle cx="7" cy="7" r="1.5"></circle></svg>
              <span>${categoryName}</span>
            </div>
            <div class="item-meta-row">
              <svg class="item-meta-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
              <span class="text-truncate">${this.escapeHtml(item.location)}</span>
            </div>
            <div class="item-meta-row">
              <svg class="item-meta-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              <span>${item.date}${item.time ? ' at ' + item.time : ''}</span>
            </div>
          </div>
        </div>

        <div class="item-card-footer">
          <button class="btn btn-sm btn-light" onclick="App.openItemDetail('${item.id}')">
            View Details
          </button>
          <button class="btn btn-sm btn-secondary" onclick="App.openItemMatches('${item.id}')" title="Check AI matches">
            Check Matches
          </button>
          ${claimButtonHtml}
        </div>
      </div>
    `;
  },

  /**
   * Render Smart Matches View
   */
  renderMatchesView() {
    const container = document.getElementById("matches-list-container");
    if (!container) return;

    const allItems = StorageService.getItems();
    const pairs = Matcher.getAllCampusMatches(allItems);

    // Update nav counter
    const navBadge = document.getElementById("nav-matches-badge");
    if (navBadge) navBadge.textContent = pairs.length;

    if (pairs.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">✨</div>
          <h3>No Smart Matches Detected Yet</h3>
          <p>When lost and found reports share matching categories, names, locations, and dates, they will automatically appear here with calculated confidence scores.</p>
          <button class="btn btn-primary" onclick="App.navigateTo('report-lost')">Report an Item</button>
        </div>
      `;
      return;
    }

    container.innerHTML = pairs.map(match => {
      const lost = match.lostItem;
      const found = match.foundItem;

      const reasonsHtml = match.reasons.map(r => `
        <li>
          <strong>${r.factor} (+${r.points} pts):</strong> ${r.text}
        </li>
      `).join("");

      return `
        <div class="match-pair-card">
          <div class="match-pair-header">
            <div class="match-score-pill">
              <span class="match-percentage">${match.score}% Match</span>
              <span class="badge ${match.badgeClass}">${match.confidence}</span>
            </div>
            <div>
              <span style="font-size:0.84rem; color:var(--text-muted);">
                Cross-compared between Active Lost and Found Listings
              </span>
            </div>
          </div>

          <div class="match-pair-grid">
            <!-- Lost Item Side -->
            <div class="match-item-column lost-side">
              <img class="match-thumb" src="${lost.imageUrl}" alt="${lost.title}">
              <div class="match-details">
                <span class="badge badge-lost" style="font-size:0.65rem; margin-bottom:0.25rem;">Lost Report</span>
                <h4>${this.escapeHtml(lost.title)}</h4>
                <p>📍 ${this.escapeHtml(lost.location)}</p>
                <p>📅 ${lost.date}</p>
                <button class="btn btn-sm btn-light" style="padding:2px 8px; font-size:0.75rem;" onclick="App.openItemDetail('${lost.id}')">View Full Report</button>
              </div>
            </div>

            <!-- Divider Arrow -->
            <div class="match-divider-icon">
              ⇄
            </div>

            <!-- Found Item Side -->
            <div class="match-item-column found-side">
              <img class="match-thumb" src="${found.imageUrl}" alt="${found.title}">
              <div class="match-details">
                <span class="badge badge-found" style="font-size:0.65rem; margin-bottom:0.25rem;">Found Report</span>
                <h4>${this.escapeHtml(found.title)}</h4>
                <p>📍 ${this.escapeHtml(found.location)}</p>
                <p>📅 ${found.date}</p>
                <button class="btn btn-sm btn-light" style="padding:2px 8px; font-size:0.75rem;" onclick="App.openItemDetail('${found.id}')">View Full Report</button>
              </div>
            </div>
          </div>

          <!-- Matching Engine Reasons Breakdown -->
          <div class="match-reasons-box">
            <div class="match-reasons-title">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
              Matching Engine Criteria Breakdown
            </div>
            <ul class="match-reasons-list">
              ${reasonsHtml}
            </ul>
          </div>

          <div class="match-pair-footer">
            <button class="btn btn-light" onclick="App.openMatchComparison('${lost.id}', '${found.id}')">
              Compare Side-by-Side
            </button>
            <button class="btn btn-primary" onclick="App.openClaimModal('${found.id}')">
              Initiate Claim for Found Item
            </button>
          </div>
        </div>
      `;
    }).join("");
  },

  /**
   * Open Matches specific to one item
   */
  openItemMatches(itemId) {
    const item = StorageService.getItemById(itemId);
    if (!item) return;

    const allItems = StorageService.getItems();
    const matches = Matcher.findMatchesFor(item, allItems);

    if (matches.length === 0) {
      this.showToast(`No high-confidence matches found for "${item.title}" yet.`, "info");
      return;
    }

    // Navigate to matches view and scroll to top
    this.navigateTo("matches");
    this.showToast(`Showing ${matches.length} matches for "${item.title}"!`, "success");
  },

  /**
   * Render Dashboard View: Reports Table, Claims Table, Stats
   */
  renderDashboard() {
    this.updatePulseMetrics();
    this.renderDashReportsTable();
    this.renderDashClaimsTable();
  },

  /**
   * Switch tabs inside the Dashboard
   */
  switchDashTab(tabId) {
    document.querySelectorAll(".dash-tab-btn").forEach(btn => {
      if (btn.getAttribute("data-tab") === tabId) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });

    document.querySelectorAll(".dash-tab-content").forEach(content => {
      content.classList.remove("active");
    });

    const targetContent = document.getElementById(`dash-tab-${tabId}`);
    if (targetContent) targetContent.classList.add("active");
  },

  /**
   * Render Reports Table in Dashboard
   */
  renderDashReportsTable() {
    const tbody = document.getElementById("dash-reports-tbody");
    const countBadge = document.getElementById("dash-tab-reports-count");
    if (!tbody) return;

    const items = StorageService.getItems();
    if (countBadge) countBadge.textContent = items.length;

    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:2rem; color:var(--text-muted);">No reports registered in database yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map(item => {
      const isLost = item.type === "lost";
      const typeBadge = `<span class="badge ${isLost ? 'badge-lost' : 'badge-found'}">${item.type.toUpperCase()}</span>`;
      
      let statusBadge = `<span class="badge badge-active">Active</span>`;
      if (item.status === "claim_pending") {
        statusBadge = `<span class="badge badge-pending">Claim Pending</span>`;
      } else if (item.status === "resolved") {
        statusBadge = `<span class="badge badge-resolved">Reunited</span>`;
      }

      const sourceBadge = item.isSample
        ? `<span class="badge badge-sample">Sample</span>`
        : `<span class="badge badge-user">★ User</span>`;

      const catObj = ITEM_CATEGORIES.find(c => c.id === item.category);

      return `
        <tr>
          <td>
            <div style="display:flex; align-items:center; gap:0.75rem;">
              <img src="${item.imageUrl}" style="width:40px; height:40px; border-radius:6px; object-fit:cover; border:1px solid var(--border);">
              <div>
                <strong>${this.escapeHtml(item.title)}</strong>
                <div style="font-size:0.75rem; color:var(--text-muted);">${item.id}</div>
              </div>
            </div>
          </td>
          <td>${typeBadge}</td>
          <td>${catObj ? catObj.label : item.category}</td>
          <td style="max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${this.escapeHtml(item.location)}</td>
          <td>${item.date}</td>
          <td>${statusBadge}</td>
          <td>${sourceBadge}</td>
          <td>
            <div style="display:flex; gap:0.35rem;">
              <button class="btn btn-sm btn-light" onclick="App.openItemDetail('${item.id}')" title="Inspect">View</button>
              <button class="btn btn-sm ${item.status === 'resolved' ? 'btn-secondary' : 'btn-success'}" onclick="App.toggleItemResolved('${item.id}')" title="Toggle Reunited">
                ${item.status === 'resolved' ? 'Re-open' : 'Reunite'}
              </button>
              <button class="btn btn-sm btn-danger" onclick="App.handleDeleteItem('${item.id}')" title="Delete">✕</button>
            </div>
          </td>
        </tr>
      `;
    }).join("");
  },

  /**
   * Render Claims Table in Dashboard
   */
  renderDashClaimsTable() {
    const tbody = document.getElementById("dash-claims-tbody");
    const countBadge = document.getElementById("dash-tab-claims-count");
    if (!tbody) return;

    const claims = StorageService.getClaims();
    if (countBadge) countBadge.textContent = claims.length;

    if (claims.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">No ownership claims submitted yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = claims.map(claim => {
      const item = StorageService.getItemById(claim.itemId);
      const itemTitle = item ? item.title : `Item ${claim.itemId}`;

      let statusBadge = `<span class="badge badge-pending">Pending Review</span>`;
      if (claim.status === "approved") {
        statusBadge = `<span class="badge badge-resolved">Approved & Reunited</span>`;
      } else if (claim.status === "rejected") {
        statusBadge = `<span class="badge badge-lost">Declined</span>`;
      }

      const actionsHtml = claim.status === "pending" ? `
        <div style="display:flex; gap:0.35rem;">
          <button class="btn btn-sm btn-success" onclick="App.handleReviewClaim('${claim.id}', 'approved')">Approve & Reunite</button>
          <button class="btn btn-sm btn-light" onclick="App.handleReviewClaim('${claim.id}', 'rejected')">Decline</button>
        </div>
      ` : `<span style="font-size:0.8rem; color:var(--text-muted);">Decision finalized</span>`;

      return `
        <tr>
          <td><strong>${claim.id}</strong></td>
          <td>
            <strong>${this.escapeHtml(itemTitle)}</strong>
            ${item ? `<div style="font-size:0.75rem; color:var(--text-muted);">${item.location}</div>` : ''}
          </td>
          <td>
            <strong>${this.escapeHtml(claim.claimerName)}</strong>
            <div style="font-size:0.75rem; color:var(--text-muted);">ID: ${this.escapeHtml(claim.studentId)}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${this.escapeHtml(claim.claimerEmail)}</div>
          </td>
          <td style="max-width:240px; font-size:0.82rem; line-height:1.4;">
            <div style="background:var(--bg-subtle); padding:6px 10px; border-radius:6px;">
              "${this.escapeHtml(claim.verificationProof)}"
            </div>
          </td>
          <td style="font-size:0.82rem;">${this.escapeHtml(claim.preferredPickupLocation)}</td>
          <td>${statusBadge}</td>
          <td>${actionsHtml}</td>
        </tr>
      `;
    }).join("");
  },

  /**
   * Toggle item resolved status
   */
  toggleItemResolved(itemId) {
    const item = StorageService.getItemById(itemId);
    if (!item) return;

    const nextStatus = item.status === "resolved" ? "active" : "resolved";
    StorageService.updateItem(itemId, { status: nextStatus });
    this.showToast(
      `Item status changed to ${nextStatus === "resolved" ? "Reunited / Resolved" : "Active"}.`,
      "success"
    );
    this.refreshAllData();
  },

  /**
   * Delete item
   */
  handleDeleteItem(itemId) {
    if (confirm("Are you sure you want to delete this report? This cannot be undone.")) {
      StorageService.deleteItem(itemId);
      this.showToast("Report deleted successfully.", "info");
      this.refreshAllData();
    }
  },

  /**
   * Approve or decline claim
   */
  handleReviewClaim(claimId, status) {
    const actionLabel = status === "approved" ? "Approve and Mark Reunited" : "Decline";
    if (confirm(`Are you sure you want to ${actionLabel} this claim?`)) {
      StorageService.updateClaim(claimId, status);
      this.showToast(
        status === "approved"
          ? "✓ Claim approved! Item is marked as Reunited with owner."
          : "Claim declined.",
        status === "approved" ? "success" : "info"
      );
      this.refreshAllData();
    }
  },

  /**
   * Reset data to initial demonstration sample set
   */
  handleResetToSample() {
    if (confirm("Reset application to default demonstration sample data? All newly added user reports will be replaced with clean demo items.")) {
      StorageService.resetToSampleData();
      this.showToast("Application reset to sample demo data successfully.", "success");
      this.refreshAllData();
    }
  },

  /**
   * Wipe all localStorage data
   */
  handleClearAllData() {
    if (confirm("Warning: This will clear ALL items and claims from localStorage. Proceed?")) {
      StorageService.clearAll();
      this.showToast("All items and claims cleared from storage.", "info");
      this.refreshAllData();
    }
  },

  /**
   * Open Item Details Modal
   */
  openItemDetail(itemId) {
    const item = StorageService.getItemById(itemId);
    if (!item) return;

    const modalTitle = document.getElementById("detail-modal-title");
    const modalBody = document.getElementById("detail-modal-body");
    const modalFooter = document.getElementById("detail-modal-footer");

    const isLost = item.type === "lost";
    const typeBadge = `<span class="badge ${isLost ? 'badge-lost' : 'badge-found'}">${isLost ? 'LOST ITEM' : 'FOUND ITEM'}</span>`;
    
    let statusBadge = `<span class="badge badge-active">Active</span>`;
    if (item.status === "claim_pending") {
      statusBadge = `<span class="badge badge-pending">Claim Pending</span>`;
    } else if (item.status === "resolved") {
      statusBadge = `<span class="badge badge-resolved">Reunited</span>`;
    }

    const sourceBadge = item.isSample
      ? `<span class="badge badge-sample">Sample Data</span>`
      : `<span class="badge badge-user">★ User Reported</span>`;

    const catObj = ITEM_CATEGORIES.find(c => c.id === item.category);

    modalTitle.innerHTML = `${item.title}`;

    // Find smart matches for this item specifically
    const allItems = StorageService.getItems();
    const specificMatches = Matcher.findMatchesFor(item, allItems);

    let matchSectionHtml = "";
    if (specificMatches.length > 0) {
      matchSectionHtml = `
        <div style="margin-top:1.5rem; padding-top:1.25rem; border-top:1px solid var(--border);">
          <h4 style="font-size:1rem; font-weight:700; color:var(--primary); margin-bottom:0.75rem; display:flex; align-items:center; gap:0.4rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="12 6 12 12 16 14"></polygon></svg>
            Smart Matches Detected (${specificMatches.length})
          </h4>
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            ${specificMatches.slice(0, 3).map(m => {
              const counterpart = m.itemB;
              return `
                <div style="background:var(--primary-light); border:1px solid var(--primary-subtle); border-radius:8px; padding:0.75rem; display:flex; justify-content:space-between; align-items:center;">
                  <div>
                    <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.25rem;">
                      <span class="badge ${m.badgeClass}">${m.score}% Match</span>
                      <strong>${this.escapeHtml(counterpart.title)}</strong>
                    </div>
                    <div style="font-size:0.78rem; color:var(--text-muted);">
                      📍 ${counterpart.location} • 📅 ${counterpart.date}
                    </div>
                  </div>
                  <button class="btn btn-sm btn-secondary" onclick="App.closeModal('modal-item-detail'); App.openItemDetail('${counterpart.id}')">
                    Inspect
                  </button>
                </div>
              `;
            }).join("")}
          </div>
        </div>
      `;
    }

    modalBody.innerHTML = `
      <div class="detail-view-grid">
        <div>
          <img src="${item.imageUrl}" class="detail-thumb" alt="${item.title}">
          <div style="margin-top:0.75rem; display:flex; flex-wrap:wrap; gap:0.4rem;">
            ${typeBadge}
            ${statusBadge}
            ${sourceBadge}
          </div>
        </div>
        <div>
          <div style="font-size:0.85rem; color:var(--text-muted); margin-bottom:0.25rem;">
            Category: <strong>${catObj ? catObj.label : item.category}</strong>
          </div>
          <h2 style="font-size:1.45rem; font-weight:800; margin-bottom:0.75rem; color:var(--text-main);">${this.escapeHtml(item.title)}</h2>
          
          <div style="background:var(--bg-subtle); padding:0.85rem; border-radius:8px; margin-bottom:1rem; font-size:0.88rem; line-height:1.6;">
            <strong>Full Description:</strong><br>
            ${this.escapeHtml(item.description)}
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem; font-size:0.84rem; margin-bottom:1rem;">
            <div>
              <span style="color:var(--text-muted);">Campus Location:</span><br>
              <strong>${this.escapeHtml(item.location)}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">Date & Time Reported:</span><br>
              <strong>${item.date}${item.time ? ' at ' + item.time : ''}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">Reporter Name:</span><br>
              <strong>${this.escapeHtml(item.reporterName)}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">Contact:</span><br>
              <strong>${this.escapeHtml(item.reporterContact)}</strong>
            </div>
          </div>

          ${item.secretVerificationHint ? `
            <div style="background:#fffbeb; border-left:3px solid var(--warning); padding:0.75rem; border-radius:6px; font-size:0.82rem; color:#92400e;">
              <strong>Verification Hint / Challenge:</strong><br>
              "${this.escapeHtml(item.secretVerificationHint)}"
            </div>
          ` : ''}

          ${matchSectionHtml}
        </div>
      </div>
    `;

    // Footer actions
    let actionButtons = `<button class="btn btn-light" onclick="App.closeModal('modal-item-detail')">Close</button>`;
    if (item.type === "found" && item.status !== "resolved") {
      actionButtons = `
        <button class="btn btn-light" onclick="App.closeModal('modal-item-detail')">Close</button>
        <button class="btn btn-primary" onclick="App.closeModal('modal-item-detail'); App.openClaimModal('${item.id}')">Claim This Item</button>
      `;
    }

    modalFooter.innerHTML = actionButtons;
    this.openModal("modal-item-detail");
  },

  /**
   * Open Claim Item Modal with Ownership Verification
   */
  openClaimModal(itemId) {
    const item = StorageService.getItemById(itemId);
    if (!item) return;

    document.getElementById("claim-target-item-id").value = itemId;

    // Prefill item summary snapshot
    const summary = document.getElementById("claim-item-summary");
    if (summary) {
      summary.innerHTML = `
        <img src="${item.imageUrl}" style="width:48px; height:48px; border-radius:6px; object-fit:cover;">
        <div>
          <div style="font-size:0.75rem; text-transform:uppercase; color:var(--primary); font-weight:700;">Claiming Found Item</div>
          <strong style="font-size:0.95rem;">${this.escapeHtml(item.title)}</strong>
          <div style="font-size:0.78rem; color:var(--text-muted);">Found at: ${item.location} on ${item.date}</div>
          ${item.secretVerificationHint ? `
            <div style="font-size:0.78rem; color:var(--warning); margin-top:2px;">
              <strong>Challenge:</strong> ${this.escapeHtml(item.secretVerificationHint)}
            </div>
          ` : ''}
        </div>
      `;
    }

    // Reset form fields
    const form = document.getElementById("form-claim-item");
    if (form) form.reset();

    this.openModal("modal-claim-item");
  },

  /**
   * Handle Claim Form Submit
   */
  handleClaimSubmit(event) {
    event.preventDefault();

    const itemId = document.getElementById("claim-target-item-id").value;
    const claimerName = document.getElementById("claim-name").value.trim();
    const studentId = document.getElementById("claim-student-id").value.trim();
    const claimerEmail = document.getElementById("claim-email").value.trim();
    const claimerPhone = document.getElementById("claim-phone").value.trim();
    const verificationProof = document.getElementById("claim-proof").value.trim();
    const preferredPickupLocation = document.getElementById("claim-pickup").value;

    const newClaim = StorageService.addClaim({
      itemId,
      claimerName,
      studentId,
      claimerEmail,
      claimerPhone,
      verificationProof,
      preferredPickupLocation
    });

    this.closeModal("modal-claim-item");

    this.showToast(
      `✓ Claim filed successfully (Ref: ${newClaim.id})! Verification is now pending.`,
      "success"
    );

    this.refreshAllData();
    this.navigateTo("dashboard");
    this.switchDashTab("claims");
  },

  /**
   * Open Match Comparison Modal
   */
  openMatchComparison(lostId, foundId) {
    const lost = StorageService.getItemById(lostId);
    const found = StorageService.getItemById(foundId);
    if (!lost || !found) return;

    const match = Matcher.compare(lost, found);
    const reasonsHtml = match ? match.reasons.map(r => `<li>${r.text}</li>`).join("") : "";

    const modalTitle = document.getElementById("detail-modal-title");
    const modalBody = document.getElementById("detail-modal-body");
    const modalFooter = document.getElementById("detail-modal-footer");

    modalTitle.innerHTML = `Side-by-Side Match Comparison (${match ? match.score : 0}% Match)`;

    modalBody.innerHTML = `
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem;">
        <div style="background:var(--lost-bg); border:1.5px solid rgba(220,38,38,0.25); border-radius:10px; padding:1.2rem;">
          <span class="badge badge-lost" style="margin-bottom:0.5rem;">Lost Item Report</span>
          <img src="${lost.imageUrl}" style="width:100%; height:160px; object-fit:cover; border-radius:8px; margin-bottom:0.75rem;">
          <h3 style="font-size:1.1rem; font-weight:700; margin-bottom:0.4rem;">${this.escapeHtml(lost.title)}</h3>
          <p style="font-size:0.86rem; color:var(--text-muted); margin-bottom:0.75rem;">${this.escapeHtml(lost.description)}</p>
          <div style="font-size:0.82rem;">
            <div>📍 <strong>Location:</strong> ${lost.location}</div>
            <div>📅 <strong>Date:</strong> ${lost.date}</div>
            <div>👤 <strong>Reporter:</strong> ${lost.reporterName}</div>
          </div>
        </div>

        <div style="background:var(--found-bg); border:1.5px solid rgba(109,40,217,0.25); border-radius:10px; padding:1.2rem;">
          <span class="badge badge-found" style="margin-bottom:0.5rem;">Found Item Report</span>
          <img src="${found.imageUrl}" style="width:100%; height:160px; object-fit:cover; border-radius:8px; margin-bottom:0.75rem;">
          <h3 style="font-size:1.1rem; font-weight:700; margin-bottom:0.4rem;">${this.escapeHtml(found.title)}</h3>
          <p style="font-size:0.86rem; color:var(--text-muted); margin-bottom:0.75rem;">${this.escapeHtml(found.description)}</p>
          <div style="font-size:0.82rem;">
            <div>📍 <strong>Location:</strong> ${found.location}</div>
            <div>📅 <strong>Date:</strong> ${found.date}</div>
            <div>👤 <strong>Reporter:</strong> ${found.reporterName}</div>
          </div>
        </div>
      </div>

      <div class="match-reasons-box">
        <div class="match-reasons-title">Engine Overlap Analysis:</div>
        <ul class="match-reasons-list">
          ${reasonsHtml}
        </ul>
      </div>
    `;

    modalFooter.innerHTML = `
      <button class="btn btn-light" onclick="App.closeModal('modal-item-detail')">Close</button>
      <button class="btn btn-primary" onclick="App.closeModal('modal-item-detail'); App.openClaimModal('${found.id}')">
        Initiate Claim for Found Item
      </button>
    `;

    this.openModal("modal-item-detail");
  },

  /**
   * Modal management
   */
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add("active");
      document.body.style.overflow = "hidden";
    }
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove("active");
      document.body.style.overflow = "";
    }
  },

  closeAllModals() {
    document.querySelectorAll(".modal-overlay").forEach(modal => {
      modal.classList.remove("active");
    });
    document.body.style.overflow = "";
  },

  handleOverlayClick(event, modalId) {
    if (event.target.id === modalId) {
      this.closeModal(modalId);
    }
  },

  /**
   * Toast Notification
   */
  showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span>${message}</span>
      <button style="background:none; border:none; color:inherit; cursor:pointer; margin-left:auto; font-weight:bold; padding:2px;" onclick="this.parentElement.remove()">✕</button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 4500);
  },

  /**
   * Safe string escaping
   */
  escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
};

// Start application when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
