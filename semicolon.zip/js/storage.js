/**
 * CampusConnect - Storage Layer (localStorage wrapper)
 * Persists lost/found items and ownership verification claims.
 */

const STORAGE_KEYS = {
  ITEMS: "campusconnect_items_v1",
  CLAIMS: "campusconnect_claims_v1",
  INITIALIZED: "campusconnect_initialized_v1"
};

const StorageService = {
  /**
   * Initializes local storage with sample data if first load
   */
  init() {
    try {
      const isInit = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
      if (!isInit || !localStorage.getItem(STORAGE_KEYS.ITEMS)) {
        this.resetToSampleData();
      }
    } catch (e) {
      console.error("Storage initialization error:", e);
    }
  },

  /**
   * Get all items from localStorage
   * @returns {Array} List of items
   */
  getItems() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ITEMS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Error reading items from localStorage:", e);
      return [];
    }
  },

  /**
   * Save items array to localStorage
   */
  saveItems(items) {
    try {
      localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items));
      return true;
    } catch (e) {
      console.error("Error saving items to localStorage:", e);
      return false;
    }
  },

  /**
   * Get single item by ID
   */
  getItemById(id) {
    const items = this.getItems();
    return items.find(item => item.id === id) || null;
  },

  /**
   * Add a new item report (Lost or Found)
   * User submissions always have `isSample: false`.
   */
  addItem(itemData) {
    const items = this.getItems();
    const newItem = {
      ...itemData,
      id: "item_usr_" + Date.now() + "_" + Math.random().toString(36).substr(2, 5),
      isSample: false, // Explicitly marks user submission!
      status: itemData.status || "active",
      createdAt: new Date().toISOString()
    };
    items.unshift(newItem);
    this.saveItems(items);
    return newItem;
  },

  /**
   * Update existing item fields
   */
  updateItem(id, updates) {
    const items = this.getItems();
    const index = items.findIndex(item => item.id === id);
    if (index !== -1) {
      items[index] = { ...items[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveItems(items);
      return items[index];
    }
    return null;
  },

  /**
   * Delete an item
   */
  deleteItem(id) {
    let items = this.getItems();
    const prevLength = items.length;
    items = items.filter(item => item.id !== id);
    this.saveItems(items);
    
    // Also clean up linked claims
    let claims = this.getClaims();
    claims = claims.filter(c => c.itemId !== id);
    this.saveClaims(claims);

    return items.length < prevLength;
  },

  /**
   * Get all claims
   */
  getClaims() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CLAIMS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Error reading claims from localStorage:", e);
      return [];
    }
  },

  /**
   * Save claims
   */
  saveClaims(claims) {
    try {
      localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify(claims));
      return true;
    } catch (e) {
      console.error("Error saving claims to localStorage:", e);
      return false;
    }
  },

  /**
   * Add a claim for an item with ownership verification
   */
  addClaim(claimData) {
    const claims = this.getClaims();
    const newClaim = {
      ...claimData,
      id: "claim_" + Date.now() + "_" + Math.random().toString(36).substr(2, 5),
      status: "pending",
      date: new Date().toISOString()
    };
    claims.unshift(newClaim);
    this.saveClaims(claims);

    // Update the item status to claim_pending
    if (claimData.itemId) {
      this.updateItem(claimData.itemId, { status: "claim_pending" });
    }

    return newClaim;
  },

  /**
   * Update claim status (approve / reject)
   */
  updateClaim(id, status, notes = "") {
    const claims = this.getClaims();
    const claim = claims.find(c => c.id === id);
    if (!claim) return null;

    claim.status = status;
    if (notes) claim.notes = notes;
    claim.resolvedAt = new Date().toISOString();
    this.saveClaims(claims);

    // If approved, update target item to resolved
    if (status === "approved" && claim.itemId) {
      this.updateItem(claim.itemId, { status: "resolved" });
    } else if (status === "rejected" && claim.itemId) {
      // Revert back to active if all claims rejected
      const remainingPending = claims.filter(c => c.itemId === claim.itemId && c.status === "pending" && c.id !== id);
      if (remainingPending.length === 0) {
        this.updateItem(claim.itemId, { status: "active" });
      }
    }

    return claim;
  },

  /**
   * Reset data to initial sample demonstration set
   */
  resetToSampleData() {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(INITIAL_SAMPLE_ITEMS));
    localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify(INITIAL_SAMPLE_CLAIMS));
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, "true");
  },

  /**
   * Clear all items & claims
   */
  clearAll() {
    localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.CLAIMS, JSON.stringify([]));
  }
};

// Auto-run init
StorageService.init();
