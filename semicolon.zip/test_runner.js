// Automated test suite for CampusConnect business logic using node:vm
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Mock browser localStorage and DOM globals
const store = {};
const mockWindow = {
  localStorage: {
    getItem: (k) => store[k] || null,
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: (k) => { delete store[k]; },
    clear: () => { Object.keys(store).forEach(k => delete store[k]); }
  },
  console: console
};

const context = vm.createContext(mockWindow);

// Load data.js, storage.js, matcher.js in order
const basePath = path.join(__dirname, 'js');
vm.runInContext(fs.readFileSync(path.join(basePath, 'data.js'), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(basePath, 'storage.js'), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(basePath, 'matcher.js'), 'utf8'), context);

const StorageService = vm.runInContext('StorageService', context);
const Matcher = vm.runInContext('Matcher', context);

console.log("=== CampusConnect Automated Logic Verification ===");

// 1. Initial Seeding Test
console.log("\n[Test 1] Verify Storage initialization & Sample items seeding:");
StorageService.init();
const items = StorageService.getItems();
console.log(`  ✓ Total seeded items: ${items.length} (Expected >= 10)`);
if (items.length < 10) throw new Error("Expected at least 10 sample items");

const sampleItems = items.filter(i => i.isSample === true);
console.log(`  ✓ All initial items marked isSample: true (${sampleItems.length}/${items.length})`);

// 2. User Submission Test (must be isSample: false)
console.log("\n[Test 2] Verify User-submitted items have isSample: false:");
const userItem = StorageService.addItem({
  type: "lost",
  title: "Matte Black ThinkPad X1",
  category: "electronics",
  location: "Central Library - 2nd Floor Quiet Stacks",
  date: "2026-11-16",
  description: "Carbon fiber ThinkPad laptop with red TrackPoint nub",
  reporterName: "David Cole",
  reporterContact: "d.cole@campus.edu"
});
console.log(`  ✓ User item created with ID: ${userItem.id}`);
console.log(`  ✓ userItem.isSample: ${userItem.isSample} (Expected: false)`);
if (userItem.isSample !== false) throw new Error("User item should have isSample: false");

// 3. Smart Matching Test
console.log("\n[Test 3] Verify Smart Matching Engine:");
const allItems = StorageService.getItems();
const matches = Matcher.getAllCampusMatches(allItems);
console.log(`  ✓ High-probability matches detected across campus: ${matches.length}`);
if (matches.length === 0) throw new Error("Expected matches to be detected");

matches.forEach((m, idx) => {
  if (idx < 3) {
    console.log(`    Pair ${idx + 1}: [${m.score}% - ${m.confidence}] "${m.lostItem.title}" <--> "${m.foundItem.title}"`);
    console.log(`      Criteria factors: ${m.reasons.map(r => r.factor).join(', ')}`);
  }
});

// Test pairwise matching for AirPods pair specifically
const airPodsLost = items.find(i => i.id === "item_sample_1");
const airPodsFound = items.find(i => i.id === "item_sample_2");
const pairMatch = Matcher.compare(airPodsLost, airPodsFound);
console.log(`  ✓ AirPods Match Score: ${pairMatch.score}% (${pairMatch.confidence})`);
if (pairMatch.score < 80) throw new Error("Expected AirPods pair to have high match score >= 80%");

// 4. Claim Item Flow & Verification
console.log("\n[Test 4] Verify Claim Item & Ownership Verification flow:");
const targetFound = items.find(i => i.type === "found" && i.status === "active");
console.log(`  Targeting found item: "${targetFound.title}" (${targetFound.id})`);

const claim = StorageService.addClaim({
  itemId: targetFound.id,
  claimerName: "Maya Lin",
  studentId: "STU-482910",
  claimerEmail: "maya.lin@campus.edu",
  verificationProof: "The case has an engraving on the back and my bluetooth name is Maya-Pods",
  preferredPickupLocation: "Student Union Info Desk"
});
console.log(`  ✓ Claim created with ID: ${claim.id}`);
console.log(`  ✓ Claim status: ${claim.status}`);

const updatedItem = StorageService.getItemById(targetFound.id);
console.log(`  ✓ Item status updated to: ${updatedItem.status} (Expected: claim_pending)`);
if (updatedItem.status !== "claim_pending") throw new Error("Item status should be claim_pending");

// 5. Claim Approval & Reunion
console.log("\n[Test 5] Verify Claim Approval & Item marked as Reunited:");
StorageService.updateClaim(claim.id, "approved", "Ownership verified at Student Union Info Desk");
const resolvedItem = StorageService.getItemById(targetFound.id);
console.log(`  ✓ Item status after approval: ${resolvedItem.status} (Expected: resolved)`);
if (resolvedItem.status !== "resolved") throw new Error("Item status should be resolved");

const finalClaims = StorageService.getClaims();
const approvedClaim = finalClaims.find(c => c.id === claim.id);
console.log(`  ✓ Claim status after approval: ${approvedClaim.status} (Expected: approved)`);

console.log("\n=== ALL TEST SCENARIOS PASSED SUCCESSFULLY ===");
